package com.Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.UserDAO;
import com.Db.DBConnect;
import com.User.UserDetails;

@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet
{
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		String name=req.getParameter("fname");
		String email=req.getParameter("uemail");
		String password=req.getParameter("upassword");
		 
		UserDetails us = new UserDetails();
		us.setName(name);
		us.setEmail(email);
		us.setPassword(password);
		PrintWriter out= res.getWriter();
		
		UserDAO dao= new UserDAO( DBConnect.getConn());
		boolean f= dao.addUser(us);
		HttpSession session;
		
		if(f)
		{
			//out.println("user registered succesfully");
			
			session = req.getSession();
			session.setAttribute("reg-sucess", "Registration sucessfull..");
			res.sendRedirect("Register.jsp");
		}
		else
		{
			//out.println("data not inserted");
			session = req.getSession();
			session.setAttribute("failed-msg", "Registration failed");
			res.sendRedirect("Register.jsp");
		}
		
				
	}
}
