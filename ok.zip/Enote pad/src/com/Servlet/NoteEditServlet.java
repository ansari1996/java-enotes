package com.Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DAO.PostDao;
import com.Db.DBConnect;

@WebServlet("/NoteEditServlet")
public class NoteEditServlet extends HttpServlet {

	protected void doPost(HttpServletRequest reqt, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("ok");
		
		
		
		try {
			System.out.println("ok");
			int noteid= Integer.parseInt(reqt.getParameter("note_id"));
			String Title= reqt.getParameter("title");
			String Content = reqt.getParameter("content");
			
			PostDao dao= new PostDao(DBConnect.getConn());
			Boolean f= dao.PostUpdate(noteid, Title, Content);
			System.out.println("ok");
			
			if(f)
			{
				System.out.println("updated Successfully....");
				response.sendRedirect("showNotes.jsp");
			}
			else
			{
				System.out.println("data is not updated");
			}
					
			
	} catch (Exception e) {
		e.printStackTrace();
		}
			
			
			
	
		
	}

}
