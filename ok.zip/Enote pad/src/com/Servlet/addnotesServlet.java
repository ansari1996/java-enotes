package com.Servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DAO.PostDao;
import com.Db.DBConnect;
import com.User.Post;

/**
 * Servlet implementation class addnotesServlet
 */
@WebServlet("/addnotesServlet")
public class addnotesServlet extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		
		int uid = Integer.parseInt(req.getParameter("uid"));
		String title=req.getParameter("title");
		String content=req.getParameter("content");
		PostDao dao= new PostDao(DBConnect.getConn());
		boolean f= dao.addnotes(title, content, uid);
		if(f)
		{
			System.out.println("data insert succesfully");
			res.sendRedirect("showNotes.jsp");
		}
		else
		{
			System.out.println("not inserted");
		}
	}

}
