package com.Db;

import java.sql.*;

public class DBConnect {
	private static Connection conn;
	public static Connection getConn()
	{
		
		try {
			
			if(conn==null)
			{
				String url="jdbc:mysql://localhost:3306/enotes";
				String uname="root";
				String pass="1234";
				Class.forName("com.mysql.cj.jdbc.Driver");
				conn = DriverManager.getConnection(url,uname,pass);
			}
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		
		
		return conn;
		
	}
	
	

}
